<?php
header('Location: /');
exit;